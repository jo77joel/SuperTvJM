# Super TV – Servidor (activación + descarga protegida)

## 1. Subirlo a internet (Render.com, plan con disco)
1. Crea un repositorio en GitHub y sube el contenido de esta carpeta (server.js, package.json, public/).
2. En Render: New > Web Service > conecta el repositorio.
   - Build Command: (vacío)   Start Command: npm start
3. Environment (variables):
   - ADMIN_PASS = tu clave de administrador (obligatoria, cámbiala)
   - DATA_DIR   = /data
   - MAX_DESCARGAS = 3   (descargas por cliente, opcional)
4. Disks > Add Disk: Mount Path /data (1 GB). Sin disco, el APK y los clientes se borran al reiniciar.
   (Railway: crea un Volume en /data. VPS propio: usa cualquier carpeta en DATA_DIR.)

## 2. Dominio propio
1. Compra un dominio corto (ej. stv.pe, mitv.link). Cuanto más corto, más fácil de escribir en la TV.
2. Render > Settings > Custom Domains > Add > escribe tu dominio.
3. En tu proveedor de dominio crea el registro DNS que Render te indique (CNAME o A). Tarda de 5 min a unas horas.
4. El HTTPS se activa solo.

## 3. Usarlo
1. Abre la app Super TV Admin, escribe https://tudominio.com y entra con tu clave.
2. En "App Super TV (APK)" sube tu APK (una sola vez; se vuelve a subir cuando haya versión nueva).
3. Crea un cliente > cuando te pague pulsa "Confirmar pago" > pulsa "WhatsApp".
4. El cliente abre su enlace /a/xxxxxxxx y ve el botón de descarga o la dirección para Downloader.

## Ver el diseño sin datos
Abre https://tudominio.com/a/0?demo=1

## Importante
- Deja de usar los códigos públicos de Downloader (7304617 y 1496940): cualquiera con ese código baja tu app sin pagar.
- El enlace de descarga (/d/xxxx) solo funciona si el pago está confirmado, no ha vencido y quedan descargas.
- Si un cliente cambia de TV, usa "+1 descarga" en su ficha.
- La protección contra copias del APK debe ir dentro de la app Super TV (pedir usuario o licencia al abrir).
